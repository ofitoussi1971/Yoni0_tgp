class GossipsController < ApplicationController
  def new
  end

  def create
  end
end
